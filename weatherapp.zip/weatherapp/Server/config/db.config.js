const dbLocatHost = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DB: "weatherapp"
}



module.exports = {
    dbLocatHost: dbLocatHost,
};